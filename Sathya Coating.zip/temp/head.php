<!-- Page Title -->
<title>Sathya Coatings Private Limited</title>
<!-- Favicon Icon -->
<link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png" />
<!-- Google Fonts Css-->
<link rel="preconnect" href="https://fonts.googleapis.com/" />
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin />
<link href="https://fonts.googleapis.com/css2?family=Hanken+Grotesk:ital,wght@0,100..900;1,100..900&amp;display=swap" rel="stylesheet" />
<!-- Bootstrap Css -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet" media="screen" />
<!-- SlickNav Css -->
<link href="assets/css/slicknav.min.css" rel="stylesheet" />
<!-- Swiper Css -->
<link rel="stylesheet" href="assets/css/swiper-bundle.min.css" />
<!-- Font Awesome Icon Css-->
<link href="assets/css/all.min.css" rel="stylesheet" media="screen" />
<!-- Animated Css -->
<link href="assets/css/animate.css" rel="stylesheet" />
<!-- Magnific Popup Core Css File -->
<link rel="stylesheet" href="assets/css/magnific-popup.css" />
<!-- Mouse Cursor Css File -->
<link rel="stylesheet" href="assets/css/mousecursor.css" />
<!-- Main Custom Css -->
<link href="assets/css/custom.css" rel="stylesheet" media="screen" />